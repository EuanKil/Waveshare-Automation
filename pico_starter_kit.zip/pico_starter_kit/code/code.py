# import iomapping as IO # use this for the raspberry pico devices
# import iomapping_ws as IO # use this for the waveshare based board
# https://learn.adafruit.com/cooperative-multitasking-in-circuitpython-with-asyncio?view=all
import asyncio
import time

# from raspberry import PLC  # use this for the Raspberyr Pico devices
from waveshare import PLC

"""
   Comment out the two IO lines below if you use the iomapping/iomapping_ws versions of the library
   The iomapping/iomapping_ws libraries do now uses objects and only initialise the pins.
   The waveshare/raspberry libraries use objects and include additional functionality
   use the following two lines if you import the waveshare.py or raspberry.py
"""
IO = PLC()
IO.init_all()

print("System start")
while True:
    START_BTN = not IO.IX0.value

    if  START_BTN:
        print("Running")
	IO.QX0.value = not IO.QX0.value
    

    time.sleep(0.2)


