# CircuitPython and OpenPLC starter kit for the ITAE6.100 Automation course

This archive contains all of the starting files for the Raspberry Pico and Waveshare relay board devices.

The mpy.exe file is used to convert the .py files into .mpy files which are much smaller and faster to load the the plain Python .py files.

## Documents

- **OpenPLC addressing for the Raspberry Pi Pico.docx** contains Modbus and addressing/pinout information required for using the Pico with the OpenPLC software. DOes nto include the Waveshare board yet.
- **RP2350B_Relay_board_GPIO.xlsx** contains the pinout for the Waveshare board, including the PLC address mapping. Use the pin information with the above document.
- **Pico-OpenPLC-A4-Pinout.pdf** contains the pinout for the Raspberry Pico, including the PLC address mapping.

## Firmware

The *.uf2 files are the CircuitPython firmware and OpenPLC bootstrap for the various Raspberry Pico devices and Waveshare relay board.

The Waveshare relayboard already has the *adafruit-circuitpython-waveshare_relay_board_10.2.1.uf2* firmware loaded. This is a custom build of the CircuitPython as there is currently no offical build on the CircuitPython.org site.

## Example code

There are two folders, one containing various examples and libraries and the other the code to bootstrap the CircuitPython for this course.

Use the template\.py file as a start for your code. It contains the basic structure for your CircuitPython code with comments using the files described below. 


**Key libraries**
- **iomapping\.py** - simple IO mapping of the GPIO pins to PLC addresses. Contains no classes/objects or any extra functionality. Use this with the Raspberry Pico range of devices.
- **iomapping_ws\.py** - same as above but with mappings for the Waveshare relay board,
- **raspberry\.py** - includes the above IO mapping but with addiotnal functionality expressed as a class/object. Use this with the Raspberry Pico range of devices.
- **waveshare\.py** - same as the raspberry\.py but with GPIO mapping for the Waveshare relay board instead.


--end-of-file--