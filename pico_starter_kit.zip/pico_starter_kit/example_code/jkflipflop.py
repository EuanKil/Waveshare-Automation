# basic 2 to 4 line decoder using a pico
import time


# Pico digital I/O mapping file as per the diagram Pico-OpenPLC-A4-Pinout.pdf
import waveshare as IO

# python class as a logic JK flip flop
# class created to track state of Q & not Q


class JKflipflop:
    Q = False
    notQ = True

    def ff(self, J, CK, K):
        # J = 0, K = 0
        if not J and not K:
            return self.Q, self.notQ
        # J = 1, K = 0
        if CK and J and not K:
            self.Q = J
            self.notQ = J
        # J = 0, K = 1
        if CK and not J and K:
            self.Q = J
            self.notQ = J
        # J = 1, K = 1
        if CK and J and K:
            self.Q = not J
            self.notQ = not K

        return self.Q, self.notQ


# use this as our clock that changes state as the loop iterates
# clock is ±20Hz if the loop delay has 50ms
CLK = False

# LOGIC HANDLING
# create an instance of the JKflipflop
JK = JKflipflop()

IO = PLC()
IO.init_all()
time.sleep(1)

while True:
    # process I/O logic
    # JK flipflop inputs
    J = IO.IX0.value
    K = IO.IX1.value

    # do the JK flop flop logic
    Q, notQ = JK.ff(J, CLK, K)

    IO.QX0.value = Q
    IO.QX1.value = notQ

# these lines used to confirm code is running in the loop
    LED.value = not LED.value
    time.sleep(0.05)  # 50ms loop

    CLK = not CLK  # toggle the clock state
