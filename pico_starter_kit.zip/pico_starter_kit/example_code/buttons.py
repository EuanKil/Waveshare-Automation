from waveshare import PLC
import time

# state flags
RUN_STATE = False # running state
E_STOP = False # emergency stop state

def run_proc():
    print("RUNNING")
    IO.QX0.value = not IO.QX0.value
    time.sleep(0.1)


print("Starting PLC code")	
IO = PLC()
IO.init_all()
time.sleep(1)
while True:
	
	# check if the button on DI1 was pressed (NO)
	if not E_STOP and not IO.IX0.value:
	    print("RUN")
	    RUN_STATE = True
            IO.QX7.value = RUN_STATE # turn the machine on

	# check if the button on DI2 was pressed (NC) 
	if not E_STOP and IO.IX1.value:
	    print("STOP")
	    RUN_STATE = False
	    IO.QX7.value = RUN_STATE # turn off the machine
            IO.QX0.value = RUN_STATE

	if not IO.IX2.value:
	    print("E-STOP")
	    RUN_STATE = False
	    E_STOP = True
	    
	    IO.QX7.value = RUN_STATE # turn off the machine
	    IO.QX6.value = E_STOP # turn on the alarm/siren/light
	    IO.QX0.value = RUN_STATE
	    
	else:
	    E_STOP = False
	    IO.QX6.value = E_STOP # turn off the alarm/siren/light

	if RUN_STATE:
	    run_proc()