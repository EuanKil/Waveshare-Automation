# basic template for using the Pico as a Programmable Logic controller
import time
# Pico digital I/O mapping file as per the diagram Pico-OpenPLC-A4-Pinout.pdf
import iomapping as IO



# LOGIC HANDLING
while True:
    # process I/O logic
    if IO.IX0.value:
        IO.QX0.value = True
    else:
        IO.QX0.value = False

