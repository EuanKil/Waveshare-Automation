#import iomapping as IO # use this for the raspberry pico devices
#import iomapping_ws as IO # use this for the waveshare based board
#from raspberry import PLC  # use this for the Raspberyr Pico devices
import time

from waveshare import PLC

"""
   Comment out the two IO lines below if you use the iomapping/iomapping_ws versions of the library
   The iomapping/iomapping_ws libraries do now uses objects and only initialise the pins.
   The waveshare/raspberry libraries use objects and include additional functionality
   use the following two lines if you import the waveshare.py or raspberry.py
"""
print("Initialising")
cycle_time = 20 # 20ms
IO = PLC()
IO.init_all()

print("Control loop started")
# start control loop
while True:
   start_cycle = time.monotonic() # time in milliseconds
    # toggle a relay or output
   IO.QX0.value = not IO.QX0.value

   IO.LED.value = not IO.LED.value # no LED on the waveshare board - uses RGB    
  

   # check and delay for the 20ms cycle
   end_cycle = time.monotonic()
   elapsed = end_cycle - start_cycle
   if elapsed < cycle_time:
      delay = (cycle_time - elapsed) / 1000 # convert ms to seconds for the sleep
      time.sleep(delay)
   #time.sleep(0.02) # brute force delay
   
