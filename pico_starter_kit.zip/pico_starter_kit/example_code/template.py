#import iomapping as IO # use this for the raspberry pico devices
#import iomapping_ws as IO # use this for the waveshare based board
from waveshare import PLC
#from raspberry import PLC  # use this for the Raspberyr Pico devices
import time

"""
   Comment out the two IO lines below if you use the iomapping/iomapping_ws versions of the library
   The iomapping/iomapping_ws libraries do now uses objects and only initialise the pins.
   The waveshare/raspberry libraries use objects and include additional functionality
   use the following two lines if you import the waveshare.py or raspberry.py
"""
IO = PLC()
IO.init_all()

print("Hello world")
while True:
    
    # toggle a relay or output
    IO.QX0.value = not IO.QX0.value

    IO.LED.value = not IO.LED.value # no LED on the waveshare board - uses RGB    
    time.sleep(0.1)
