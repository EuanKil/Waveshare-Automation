# basic template for using the Pico as a Programmable Logic controller
import time
import board
# Pico digital I/O mapping file as per the diagram Pico-OpenPLC-A4-Pinout.pdf
import waveshare as IO


IO = PLC()
IO.init_all()
time.sleep(1)

# LOGIC HANDLING
while True:
    # process I/O logic
    # AND gate
    if IO.IX0.value and IO.IX1.value:
        IO.QX0.value = True
    else:
        IO.QX0.value = False

    # OR gate
    if IO.IX0.value or IO.IX1.value:
        IO.QX0.value = True
    else:
        IO.QX0.value = False

    # XOR gate
    if IO.IX0.value and IO.IX1.value:
        IO.QX0.value = False
    elif IO.IX0.value or IO.IX1.value:
        IO.QX0.value = True
    else:
        IO.QX0.value = False

# these lines used to confirm code is running in the loop
    LED.value = not LED.value
    time.sleep(0.05)  # 50ms loop
