import pyRTOS
import Time

from waveshare import PLC

BUTTONS = [0,0,0,0,0]

def task(self):
    global BUTTONS
    # initialize the task then return
    IO.QX0.value = False
    yield

    # task runs in the while loop
    while True:
        BUTTONS[0] = IO.IX0.value
        IO.QX0.value = not IO.QX0.value
        yield [pyRTOS.timeout(1.3)]


print("Starting")
IO = PLC()
IO.init_all()
time.sleep(1)

pyRTOS.add_task(pyRTOS.Task(task))
pyRTOS.start()
