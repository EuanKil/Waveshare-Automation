import asyncio

from waveshare import PLC


async def task(data):
    await asyncio.sleep(2)
    return data


IO = PLC()
IO.init_all()

print("Starting")


async def main():
    data = "Some data"
    result = asyncio.create_task(task(data))
    print(f"{data}")


asyncio.run(main())
